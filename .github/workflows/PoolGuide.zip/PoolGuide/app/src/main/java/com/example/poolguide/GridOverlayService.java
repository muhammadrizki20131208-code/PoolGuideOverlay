package com.example.poolguide;

import android.app.Service;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

public class GridOverlayService extends Service {
  WindowManager wm; GridView grid;
  @Override public int onStartCommand(Intent intent,int flags,int startId){
    if(grid!=null){ try{wm.removeView(grid);}catch(Exception ignored){} }
    int alpha=intent==null?95:intent.getIntExtra("opacity",95);
    wm=(WindowManager)getSystemService(WINDOW_SERVICE); grid=new GridView(this,alpha);
    int type=android.os.Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
    WindowManager.LayoutParams p=new WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT);
    p.gravity=Gravity.TOP|Gravity.START; wm.addView(grid,p); return START_NOT_STICKY;
  }
  @Override public void onDestroy(){if(grid!=null&&wm!=null){try{wm.removeView(grid);}catch(Exception ignored){}} grid=null; super.onDestroy();}
  @Override public IBinder onBind(Intent i){return null;}
  static class GridView extends View {
    Paint red=new Paint(3), blue=new Paint(3); int a;
    GridView(android.content.Context context,int alpha){super(context); a=Math.max(15,Math.min(180,alpha)); setLayerType(View.LAYER_TYPE_SOFTWARE,null); red.setColor(Color.RED); red.setAlpha(a); red.setStrokeWidth(1.6f); red.setStyle(Paint.Style.STROKE); blue.setColor(Color.rgb(0,190,235)); blue.setAlpha(a); blue.setStrokeWidth(1.6f); blue.setStyle(Paint.Style.STROKE);}
    @Override protected void onDraw(Canvas c){super.onDraw(c); float w=getWidth(),h=getHeight(); if(w<=0||h<=0)return;
      // Dense diagonal guide families, similar to the physical pool guideline sheet.
      float step=Math.max(22,Math.min(w,h)/19f);
      for(float x=-h;x<w;x+=step){c.drawLine(x,0,x+h,h,red); c.drawLine(x, h, x+h,0,blue);}
      float step2=step*1.75f;
      for(float x=-h;x<w;x+=step2){c.drawLine(x,0,x+h,h,blue); c.drawLine(x,h,x+h,0,red);}
      // Short calibration ticks around screen edges.
      for(int i=1;i<10;i++){float x=w*i/10f; c.drawLine(x,0,x,12,blue);c.drawLine(x,h-12,x,h,red);}
      for(int i=1;i<8;i++){float y=h*i/8f;c.drawLine(0,y,12,y,red);c.drawLine(w-12,y,w,y,blue);}
    }
  }
}
