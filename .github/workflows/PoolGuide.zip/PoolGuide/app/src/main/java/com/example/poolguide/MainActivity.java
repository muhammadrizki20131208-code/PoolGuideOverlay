package com.example.poolguide;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends Activity {
  int opacity = 95;
  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(24,24,24,24); root.setGravity(Gravity.CENTER_VERTICAL); root.setBackgroundColor(Color.rgb(20,20,20));
    TextView title = new TextView(this); title.setText("Pool Guide Grid"); title.setTextColor(Color.WHITE); title.setTextSize(26); root.addView(title);
    TextView desc = new TextView(this); desc.setText("Overlay garis silang merah + biru. Aktifkan overlay, lalu buka 8 Ball Pool. Sentuhan diteruskan ke game."); desc.setTextColor(Color.LTGRAY); desc.setTextSize(16); LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1,-2); dp.setMargins(0,16,0,20); root.addView(desc,dp);
    TextView label = new TextView(this); label.setText("Kecerahan garis: " + opacity + "/255"); label.setTextColor(Color.WHITE); root.addView(label);
    SeekBar seek = new SeekBar(this); seek.setMax(180); seek.setProgress(opacity); root.addView(seek); seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){ public void onProgressChanged(SeekBar s,int p,boolean u){opacity=p; label.setText("Kecerahan garis: "+p+"/255");} public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){} });
    Button start = new Button(this); start.setText("AKTIFKAN GARIS OVERLAY"); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2); bp.setMargins(0,24,0,8); root.addView(start,bp);
    start.setOnClickListener(v -> { if(!Settings.canDrawOverlays(this)){ Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())); startActivity(i); } else { Intent i=new Intent(this,GridOverlayService.class); i.putExtra("opacity",opacity); startService(i); finish(); } });
    Button stop = new Button(this); stop.setText("MATIKAN OVERLAY"); root.addView(stop); stop.setOnClickListener(v -> stopService(new Intent(this,GridOverlayService.class)));
    TextView note=new TextView(this); note.setText("Untuk mengubah kecerahan, matikan overlay lalu aktifkan lagi. Hentikan lewat aplikasi atau notifikasi Android."); note.setTextColor(Color.GRAY); note.setTextSize(13); LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2); np.setMargins(0,18,0,0); root.addView(note,np);
    setContentView(root);
  }
}
