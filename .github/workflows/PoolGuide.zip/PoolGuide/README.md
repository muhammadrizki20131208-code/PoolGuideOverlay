# Pool Guide Grid (Android source)

A simple transparent, touch-through overlay with dense red/blue diagonal guide lines inspired by a physical 8-ball pool guideline sheet. It does not calculate the ball physics; it displays fixed guide lines.

## Build
- Open this folder in Android Studio (Giraffe or newer).
- Let Gradle sync; use JDK 17 and Android SDK 35.
- Build > Build APK(s).
- Install the generated APK, allow "Display over other apps", open the app and activate the overlay.

## Notes
- The overlay is intentionally NOT_TOUCHABLE so game taps pass through.
- To change opacity, stop the overlay and activate it again after changing the slider.
- Stop the service using the app's stop button (reopen the app from recents if needed).
- This zip is Android source code, not a ready-to-install APK. It has not been compiled or tested on a device in this environment.
